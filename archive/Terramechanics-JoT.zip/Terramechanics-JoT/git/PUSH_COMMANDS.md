# Публикация кода — без статьи

Принцип: репозиторий живёт **внутри `code/`**, а не в корне проекта. Поэтому
`manuscript/`, `submission/` и `reviews/` физически находятся вне рабочего
дерева Git и не могут попасть в коммит даже по ошибке — `git add -A` их просто
не видит.

Не делайте `git init` в корне `Terramechanics-JoT/`. Если он там когда-то был —
удалите `.git` в корне (`rm -rf .git`) и работайте по инструкции ниже.

---

## 1. Первая настройка (один раз)

```bash
cd "~/Science Article 2025-/Terramechanics-based evaluation of anair-cushion-assisted wheeled vehicle on deformableterrain/Terramechanics-JoT/code"

git init
git branch -M main
git add .
git status            # проверьте список: только .py, .json, .txt, .cff, .md, LICENSE
git commit -m "Terramechanics model: equilibrium slip, nine limit-case checks"
git remote add origin https://github.com/Dev-Nikita/<repo>.git
git push -u origin main
```

Перед первым push замените `<repo>` на имя репозитория и впишите его же в
`code/CITATION.cff`, поле `repository-code`.

## 2. Обновление после правок кода

```bash
cd .../Terramechanics-JoT/code
python3 terramechanics_model.py        # убедиться, что девять проверок проходят
git add -A
git status
git commit -m "<что изменилось>"
git push
```

## 3. Контрольная проверка перед каждым push

```bash
git ls-files | grep -Ei '\.(tex|pdf|docx|bib|bbl)$' && echo "СТОП: в индексе документ" || echo "OK: только код"
```

Команда должна напечатать `OK: только код`. Если напечатала `СТОП` — файл попал
в индекс, уберите его: `git rm --cached <файл>` и закоммитьте заново.

Посмотреть, что именно уйдёт, до отправки:

```bash
git diff --stat origin/main..HEAD
```

## 4. Что коммитится

| Файл | В Git | Причина |
|---|---|---|
| `terramechanics_model.py` | да | на него ссылается Data availability |
| `fig1_schematic.py`, `fig2a_geometry.py` | да | генерируют Fig. 2 |
| `results.json` | да | машиночитаемый дамп всех значений |
| `requirements.txt`, `LICENSE`, `CITATION.cff`, `README.md` | да | метаданные репозитория |
| `article.tex`, `article.pdf`, `article.docx` | **нет** | неопубликованная рукопись |
| `response_to_reviewers.*`, `cover_letter*` | **нет** | переписка с редакцией |
| `refs.bib`, `supplementary.*` | **нет** | часть рукописи |
| отзывы рецензентов | **нет** | конфиденциальны по правилам Elsevier |
| `fig/`, `__pycache__/`, `.DS_Store` | нет | генерируемое, в `.gitignore` |

Репозиторий делайте **public** только после того, как статья принята, либо
сразу — но тогда в нём не должно быть ничего, кроме кода. Код сам по себе не
раскрывает текст статьи; preprint-политика Elsevier публикацию кода не
запрещает.

## 5. Zenodo

1. Откройте существующую запись (concept DOI `10.5281/zenodo.21862564`).
2. **New version** → удалить старый файл → загрузить `zenodo/zenodo_v1.2.0.zip`.
3. Version: `1.2.0`, дата — текущая, авторы и лицензия MIT без изменений.
4. Publish. Убедитесь, что concept DOI открывает уже новую версию.
5. Если связываете Zenodo с GitHub — делайте release в репозитории `code`,
   тогда архив соберётся из него автоматически и будет содержать только код.

Пока это не сделано, подавать ревизию нельзя: Data availability в статье
утверждает, что по DOI лежит код, воспроизводящий результаты, а там версия 0.2
от 9 августа 2026 (19,3 кБ) — то есть код до исправления скольжения.
