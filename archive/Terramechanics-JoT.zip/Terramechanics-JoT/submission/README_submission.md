# Journal of Terramechanics — final submission package

## What to upload to Editorial Manager

| Item type | File |
|---|---|
| Cover letter | `cover_letter.docx` (source: `cover_letter.md`) |
| Manuscript | `manuscript.pdf` — or `manuscript.docx` if the system asks for an editable file |
| Highlights | `highlights.txt` — 5 bullets, longest 75 characters |
| Supplementary material | `supplementary.pdf` |
| Supplementary material | `code/` — zip it, or give the GitHub URL |
| Figures | `figures/Fig1…Fig10` — vector PDF plus 300 dpi PNG, named in document order |
| LaTeX source | `latex_source/` — if the journal requests it after acceptance |

Build: `pdflatex manuscript` → `bibtex manuscript` → `pdflatex` ×2.
Word version: run bibtex first, then `python3 make_docx.py manuscript.tex manuscript.docx`.

The manuscript now uses the **official `elsarticle` class**, generated from the
bundle you supplied, with `elsarticle-harv.bst` and a real BibTeX database. Class
options are `preprint,review,12pt,authoryear`, so the PDF is double-line-spaced
as the journal asks. Highlights, keywords, corresponding-author marking and the
affiliation block all use the native elsarticle commands.

---

## Figure 1

The CAD render you put back is the right decision for a design study — it shows
the actual machine, and as your own model it raises no rights question. But on
its own it does not show the cushion, the skirt clearance, the pressure or any
of the forces the paper is about, so a reader arriving at Section 3 has nothing
to look at.

It is now **split into two figures**, as you asked, rather than one crowded one:

- **Fig. 1** — your CAD general arrangement, callouts 1–5 as before.
- **Fig. 2** — a schematic drawn from scratch showing G, W_w, F_ac, Δp, F_x,
  F_res, the rut depth z, the skirt clearance h_g, the leakage Q, the cushion
  planform area and the skirt perimeter. Every symbol in it appears in the
  Nomenclature.

**One thing needs your attention.** The CAD render is 644 × 399 px. At the width
used in the manuscript that is about 180 dpi, below the 300 dpi Elsevier asks for
combination artwork. Please re-export it from your CAD package at 300 dpi or
higher (or as EPS/PDF, which is better still) and drop it in as
`fig1a_cad.png`. Nothing else needs changing.

---

## Terminology

**"tire" vs "tyre".** The journal is Elsevier and international, and both
spellings are acceptable provided the manuscript is internally consistent. In
practice the *Journal of Terramechanics* uses American spelling almost
throughout — "tire–terrain interaction", "modeling", "Tire" is even a keyword in
He et al. (2020). The manuscript has therefore been converted to **consistent
American English**: tire, modeling, minimization, optimization, idealization,
characterized, analyzed, behavior, mobilization, immobilized, labeled. 50
substitutions in the manuscript, 2 in the supplement. Reference titles were left
exactly as published, so you will still see British spellings inside the
bibliography — that is correct and should not be "fixed".

**"terramechanics".** Correct and standard; it is the name of the field and of
the journal. Lower case in running text, capitalised only as the first word of
the title and inside journal names. No change needed.

**"aerocompensator".** This one is worth being careful about. It is established
in Ukrainian and Russian engineering literature but has essentially no currency
in English-language terramechanics, and a reviewer meeting it cold will read it
as either a neologism or a translation artefact. It is not in the title, the
abstract, the highlights or the keywords. It appears **once**, in the
Introduction, in this form:

> In the Ukrainian engineering literature such a device is called an
> aerocompensator; the term air-cushion load-relief system is used in what
> follows.

That is the right amount. It credits the term without asking the reader to adopt
it, and everywhere else the paper says "air-cushion load-relief system" or
"cushion". I would not remove it entirely — it is your term and it belongs in
the record — and I would not use it any more than this.

---

## How much does the paper look AI-written?

I went through the text looking for the usual markers. Here is an honest report.

**Removed in this pass:**

- Em-dash-heavy sentence construction. The manuscript had roughly forty em
  dashes used as dramatic pauses; they are now commas, semicolons or full stops
  except where a genuine parenthetical is intended.
- Rhetorical scaffolding: "It is important to note", "deserve emphasis", "It must
  be stated plainly", "the most practically consequential", "worth noting".
- Tricolon openers ("Three findings deserve emphasis", "Four findings deserve
  emphasis") replaced with plain topic sentences.
- Superlative self-assessment ("the strongest new result", "decisive").

**Still present, and deliberately so:**

- Numbered contribution lists and numbered conclusions. These are standard
  Elsevier practice, not an AI tell.
- Explicit limitation lists. Also standard, and in this paper they are doing real
  work.
- Highly regular paragraph structure in the Results. This is what a
  parameter-study Results section looks like; leaving it uneven to seem more
  human would be a mistake.

**My overall read:** the prose no longer patterns as machine-generated. What
would give it away, if anything, is not the writing but the *uniformity of the
figures* — ten plots in one matplotlib style with identical typography. That
reads as "generated by one script", which is exactly true and is stated in the
Methods, so it is not a problem. The one genuinely human-looking element is now
Fig. 1, your CAD.

The detail that matters more than any of this: the AI declaration is filled in
and names Grammarly, DeepL and GitHub Copilot with their specific roles. A
disclosed declaration is routine and editorially neutral. An undisclosed one
that surfaces later is not.

---

## Readiness assessment against the Guide for Authors

| Requirement | Status |
|---|---|
| Article type: full-length, Theory/Calculation | Yes |
| Abstract ≤ 200 words | 198 |
| Highlights: 3–5 bullets, ≤ 85 characters each | 5 bullets, 65–75 characters |
| All authors, affiliation, corresponding author on title page | Yes, via elsarticle |
| Continuous line numbering | Yes, throughout including references |
| Double-line spacing | Yes, `review` class option |
| Nomenclature | Yes, after the frontmatter |
| CRediT statement | Yes |
| Declaration of competing interest | Yes |
| Data availability statement | Yes, with GitHub and Zenodo placeholders |
| Generative AI declaration | Yes, completed |
| Figures ≥ 300 dpi | 9 of 10; **Fig. 1 needs re-export** |
| References in Elsevier Harvard style | Yes, `elsarticle-harv.bst` via BibTeX |
| Length ≤ 20 double-spaced pages "preferably" | **40 pages** — see below |

**On length.** Forty double-spaced pages including 10 figures and 6 tables comes
to roughly 13–15 typeset journal pages, which is normal for this journal, and the
guide says "preferably", not "must". I would submit as is. If you would rather
comply literally, the cheapest 8–10 pages are: move the Nomenclature to the
supplement, move Table 6 (the organic-soil force balance) to the supplement and
keep only Fig. 6, and cut Section 7.6 on slip dependence to a paragraph with the
figure moved to the supplement. Say the word and I will do it, but my
recommendation is to leave the science in the main text.

---

## What is left for you

1. **Corresponding author e-mail** in `manuscript.tex` (`\ead{}`) and in the
   cover letter.
2. **ORCID identifiers** if you have them — entered in Editorial Manager, not in
   the manuscript. The journal does not require them.
3. **Re-export Fig. 1 at 300 dpi or as vector.**
4. **Create the GitHub repository**, push `code/`, then archive it on Zenodo and
   paste both the URL and the DOI into the Data Availability statement. See
   `code/README.md`, which is written and ready.
5. **Confirm Fig. 1 is genuinely your own CAD model.** The cover letter states
   that it is. If any part of it came from elsewhere, tell me and it comes out.
6. **Suggested reviewers.** Editorial Manager will ask for three to five. Pick
   from authors already in your reference list whose work is closest: the paper
   engages directly with Wong's framework, with Sandu's group at Virginia Tech
   (Taheri et al., He et al., Senatore and Sandu), with Vantsevich and Gray on
   multi-wheel-drive energy efficiency, and with Vella and colleagues on
   soft-soil tire contact. Do not suggest anyone from your own institution or a
   recent co-author.
7. **Final read of the PDF**, particularly equations 1–18 and the two new figure
   captions.

---

## What goes into the public repository, and what does not

Publish `code/` exactly as packaged: `terramechanics_model.py`,
`fig1_schematic.py`, `results.json` and `README.md`, under the MIT license.
That is the entire computational content of the paper and it reproduces every
number in it.

Do **not** publish: the manuscript LaTeX source, the figures as generated
artefacts (the script regenerates them), or the CAD model unless you have
decided independently to release the design. Journals do not expect the
manuscript source in a data repository, and releasing the CAD is a separate
commercial decision that has nothing to do with the paper.

GitHub alone is not sufficient for the Data Availability statement, because a
GitHub repository can be deleted or rewritten and has no persistent identifier.
Archive a tagged release on Zenodo — the GitHub–Zenodo integration does this in
about five minutes — and cite the Zenodo DOI in the paper, with the GitHub URL
alongside it for convenience. That is what Elsevier's data policy is asking for.

---

# Final pass — what changed in this revision

Every item on the reviewer's pre-submission checklist has been applied.

1. **`doi:.` in the Word bibliography — fixed at the root.** This was a real bug
   in `make_docx.py`, not a display artefact. BibTeX emits DOIs as
   `\DOIprefix\doi{10.1016/...}`; the converter expanded the prefix but left the
   `\doi{}` macro, which pandoc silently dropped, leaving `doi:.` The converter
   now expands `\doi`, `\href`, `\path` and `\url`, and deletes any orphaned
   `doi:.` The Word file now shows 11 real DOIs and zero broken ones. Entries
   without a DOI print no `doi:` at all.
2. **Data availability placeholders removed.** No dead GitHub URL and no
   promised Zenodo DOI. The statement now says the code is supplied as
   supplementary material and will be deposited with a persistent identifier on
   acceptance. A LaTeX comment marks the spot if you get the repository live
   before you submit.
3. **"or any other speed" removed.** The sentence now reads: the unassisted
   configuration is traction-infeasible at the prescribed operating point. The
   old wording claimed the whole (v, s) space, which the model does not cover.
4. **Abstract narrowed.** "the dominant uncertainty" became "contact-geometry
   uncertainty as larger than the terrain-parameter scatter examined", which is
   what was actually shown. Abstract is 196 words.
5. **Highlight 2 corrected** to "different load-relief fractions" — 84
   characters, inside the limit.
6. **Meta-phrases removed:** "reported rather than suppressed", "Stated
   carefully", "This reordering of priorities is itself a result", "The
   comparison figure requires care".
7. **Control claim softened:** "A control system would treat" became "In a
   control implementation, α_min could serve as a lower feasibility bound with
   an appropriate safety margin".
8. **Copilot added to the Methods**, not only the declaration: one sentence in
   the Solution procedure stating that generated code was reviewed by the
   authors and tested against the analytical limit cases. Elsevier treats AI
   used inside the research process differently from AI used to prepare the
   manuscript, so it belongs in both places.
9. **Remaining British spellings cleaned** (realisation, characterising,
   realisable). Reference titles untouched.
10. **Clean-room reproduction test passed.** The code was copied to an empty
    directory and run from scratch: all **nine** limit checks pass, α\* = 0.642
    and all figure files regenerate; `results.json` is byte-identical to the
    copy shipped in this package.


## Final audit pass (19 October 2026)

An independent re-read of the revised PDF found six defects in the revision
itself. All are fixed in the files in this package, and the manuscript, both
DOCX files, the figures and `results.json` were rebuilt afterwards.

1. **False equivalence removed.** The text claimed that "no root exists below
   s = 0.9" was *the same condition* as K_TR < 1. It is not: on organic soil a
   root exists from α = 0.35, while K_TR ≥ 1 only from α_trac = 0.404. Section
   3.7 now separates *physical existence* from *operational admissibility* and
   states the relation that does hold exactly, as a new numbered equation (15):
   K_TR(α) ≥ 1 ⟺ F_x(α, 0.25) ≥ F_res(α) ⟺ s_eq(α) ≤ 0.25.
2. **Verification suite extended to nine cases.** The new case checks that
   equivalence over 1901 values of α; zero mismatches. Table S1 updated.
3. **P_max dropped from the optimization statement.** It was never defined and
   never imposed. The text now says no fan-power limit is applied and that
   P_fan is reported so a reader can apply one.
4. **Solver wording corrected.** Slip is obtained by bisection; everything else
   is closed-form. The earlier "no iterative solver required" was wrong.
5. **Stale numbers corrected.** The Discussion said the energy minimum lies at
   α = 0.60 (it is 0.64), and the slip-loss shares were wrong. They are now
   21 % of the propulsive demand at the traction bound and 5 % at the optimum,
   both verified against the model, and the Conclusions quote the admissible
   bound α_trac = 0.404 rather than the inadmissible α = 0.40.
6. **Response documents rewritten to match.** The reply to Reviewer 2's
   Comment 3 now describes the final, self-consistent model — the existence /
   admissibility split and the exact K_TR–slip equivalence — rather than the
   intermediate recomputation.

## Still yours to do before you press Submit

- Corresponding author e-mail in `\ead{}` and in the cover letter.
- Re-export Fig. 1 from CAD at 300 dpi or as vector.
- **If you used any other AI tool** — ChatGPT, Claude, Gemini — for drafting,
  rewriting, literature synthesis or wording of the Discussion or Abstract, add
  it to the declaration. The declaration currently names Grammarly, DeepL and
  GitHub Copilot only. Elsevier permits AI-assisted preparation with disclosure;
  an incomplete disclosure discovered later is the damaging outcome, not the use
  itself.
- Three to five suggested reviewers in Editorial Manager.

---

# Pass 2 — cover letter, LaTeX audit and bibliography verification

## Cover letter rewritten

Cut from about 900 words to **463** in the body, and the six labelled sections
("Subject and motivation", "Approach", "Principal findings", "Scope of the
claims", "Fit to the journal", "Declarations") replaced with continuous
paragraphs. Removed: "Four results may interest the readership of this journal",
"We wish to be explicit with the Editor about what the manuscript does and does
not establish", "We have preferred to expose these boundaries rather than to
present the results as more secure than they are", the list of fifteen surnames,
and "its natural home". The limitation is now one sentence. The Zenodo DOI is
cited.

## Corresponding author — check this

There is no conflict in the files as they stand: `\corref{cor1}` and `\ead{}`
are both on **Andrii Bokhonko** in `manuscript.tex`, and the cover letter is
signed by him. Decide deliberately, though, and keep it identical in three
places — manuscript, cover letter and Editorial Manager. If correspondence will
actually be handled by N. Tarasov, move `\corref{cor1}` and `\ead{}` to his
`\author` line (two lines in the frontmatter), change the signature block in
`cover_letter.md`, and rebuild. The corresponding author need not be the first
author.

## LaTeX audit

- Compiles clean: no errors, no undefined references, no undefined citations.
- All 18 equation labels, 10 figure labels, 6 table labels and 34 citation keys
  resolve. Nothing cited is missing from `refs.bib`; nothing in `refs.bib` is
  uncited.
- Overfull boxes reduced from 7 (worst 65 pt) to 3 (worst 16 pt) by narrowing
  Table 1's Basis column, splitting the Table 5 header over two rows and
  abbreviating one column head in Table 6. The remainder are under 0.6 cm and
  invisible in print.
- Eight labels are defined but never referenced (`eq:vert`, `eq:alpha`,
  `eq:sinkage`, `eq:dp`, `eq:ktr`, `eq:wlmr`, `sec:energy`, `sec:terrain`).
  Harmless — the equations are still numbered and can be cited by reviewers.

## Bibliography: verification, and one real error found

The list is **not** machine-generated. I checked entries individually against
ScienceDirect, Semantic Scholar, ADS and citing papers. Verified this pass:
Senatore and Iagnemma 2014 (J. Terramech. 51, 1–17, doi added), Priddy and
Willoughby 2006 (43, 85–96), Wong and Reece 1967 Part I (4(1), 81–98),
He et al. 2020, Hetherington 2001, Lyasko 2010 (47(1), 1–19),
Meirion-Griffith and Spenko 2011 (48(2), 149–155). Verified in the previous
pass: Ding 2011, Du 2017, Gray 2016, Senatore and Sandu 2011, Surkutwar 2024,
Taheri 2015, Vantsevich 2008, Vella 2025, Wismer and Luth 1973, Wong and
Preston-Thomas 1983, Wong et al. 1982.

**One entry was wrong and is fixed.** El-Khatib and Hussein (2013) was listed in
the *International Journal of Scientific Research in Science, Engineering and
Technology*. The paper is real but appeared in the *International Journal of
Engineering Research and Technology*, vol. 2, issue 12, 2013. Corrected.

**Two entries were removed** because I could not confirm them from an
independent source: Riyadi et al. (2016) and Wang et al. (2013), both
conference papers on hovercraft control. They supported one sentence that is not
load-bearing. In their place is Karami and Ghasemi (2021), *Journal of Marine
Science and Application* 20, 325–333, doi:10.1007/s11804-021-00201-6, verified
and a stronger source. The reference count is unchanged at 34 because the Zenodo
dataset entry was added.

Entries still carrying no DOI are the monographs (Bekker, Wong ×2, Yun and
Bliault, Amyot, MacFarlane), the pre-DOI journal papers (Reece 1965, Wong and
Reece 1967, Hetherington 2001, Lyasko 2010, Meirion-Griffith 2011, Priddy 2006),
the 1961 Janosi and Hanamoto conference paper, the CRREL report, El-Khatib and
Hussein, and your own two Ukrainian conference papers. That is normal and not a
defect.

## Data availability and AI declaration updated

The Zenodo record (doi:10.5281/zenodo.21862564) is now cited in the text, listed
in the bibliography as a dataset, and named in the Data Availability statement.
No placeholders remain there.

The AI declaration now reads: **Grammarly** for grammar and style, **ChatGPT**
for clarity, grammar and LaTeX typesetting, **GitHub Copilot** for the Python
code, all under author supervision, with an explicit statement that every
numerical value was verified against the source code and every reference against
the published source. DeepL was removed. Copilot is also named in the Methods,
where it belongs under Elsevier's separate treatment of AI used inside the
research process.

Only two things remain: the corresponding author's e-mail, and a 300 dpi
re-export of Fig. 1.

---

# Pass 3 — corresponding author, ORCID, Zenodo entry

## Corresponding author is now Nikita Tarasov, consistently

Changed in all three places that must agree:

- `manuscript.tex` — `\corref{cor1}` and `\ead{nikita.a.tarasov@lpnu.ua}` moved
  to the Tarasov author line. The title-page footnote now reads
  "Corresponding author. Email address: nikita.a.tarasov@lpnu.ua (Nikita
  Tarasov)".
- `cover_letter.md` / `.docx` — signature block is Nikita Tarasov, corresponding
  author, with the real e-mail, "on behalf of Andrii Bokhonko and Roman Zinko".
  No placeholder remains.
- **Editorial Manager** — select Nikita Tarasov as corresponding author when you
  enter the author list. This is the one place I cannot set for you.

Author order on the paper is unchanged: Bokhonko, Zinko, Tarasov. The
corresponding author does not have to be the first author, and Elsevier's system
handles this normally.

## ORCID — where it actually goes

ORCID is **not** required in the manuscript body, and elsarticle has no native
command for it. Elsevier collects ORCID through Editorial Manager: each author's
record has an ORCID field, and the corresponding author is prompted to link or
create one during submission. The identifiers are then attached to the article
metadata and appear on the published version. That is the correct route and the
only one that feeds Crossref.

If you want them printed on the title page anyway, the frontmatter of
`manuscript.tex` carries a commented template showing the `\fnref` / `\fntext`
pattern. Uncomment and fill only if all three of you have an ORCID; a partial
list looks worse than none. Do not invent identifiers.

## Zenodo bibliography entry

Worth noting: the entry parses correctly in this build — the reference renders
as "Tarasov, N., Bokhonko, A., Zinko, R., 2026." The corrupted form the reviewer
saw ("Tarasov Nikita, B.A., Roman, Z.") comes from a different build, most
likely one where `@dataset` fell through to a default entry type that the style
does not format. To remove the risk entirely the entry is now `@misc` with
`howpublished = {Zenodo}` and both `doi` and `url` fields, and the leading "T"
of the title is brace-protected so the style cannot lowercase it.

## Cover letter, final polish

Converted to American spelling to match the manuscript (immobilized,
minimization, program). "Three results seem to us worth the readership's
attention" became "Three findings are particularly relevant to the journal's
readership". The novelty claim was narrowed from "To our knowledge that
condition has not been identified before" to "We have not found this condition
explicitly identified in the literature reviewed for this study" — much harder
for a referee to contest. 468 words.

## Submission form

**Article type: Research Paper.** Not Technical Note, which is capped at four
printed pages, and not Review Article.

Upload order: cover letter, manuscript (PDF, or DOCX if the system insists on an
editable file), `Highlights.docx`, figures from `figures/`, `supplementary.pdf`,
and the contents of `code/` — or simply cite the Zenodo DOI, which is already in
the Data Availability statement and the reference list.

The only item left is a 300 dpi re-export of Fig. 1 from your CAD package.

---

# Pass 4 — Figure 2

The side-view sketch your co-authors sent should not replace Fig. 2 as it
stands. The objection is not aesthetic, it is notational: three of its labels
collide with symbols the manuscript already uses.

- **b** on that sketch is a longitudinal distance. In the paper `b` is the
  contact patch width, and it appears in Eqs. (4), (7), (8) and in Table 2. Two
  meanings for one symbol in the same paper is the kind of thing a referee
  circles on page one.
- **L_p** on that sketch is a single horizontal length. In the paper `L_p` is the
  skirt *perimeter*, and it enters the leakage flow in Eq. (11). A perimeter
  drawn as a length is a physical error, not a labelling slip.
- **W** appears twice without a subscript. The paper uses `W_w`, the load on one
  wheel, which is what Eq. (3) defines.
- Missing from it entirely: Δp, Q and A_ac. Those three drive Eqs. (10) and (11)
  and therefore the whole fan-power side of the study. A figure that omits them
  represents only half the model.

It is also raster, and visibly coarser than the rest of the artwork.

**What I did instead.** Kept the flow schematic and added the geometry view your
co-authors wanted, redrawn from scratch as vector art with symbols that match
the Nomenclature. Fig. 2 now has two panels:

- **(a)** longitudinal geometry and vertical force balance: G = mg, the wheel
  reactions W_w, the cushion lift F_ac = Δp·A_ac, the wheelbase **L_wb**, the
  cushion length **L_c** and planform area A_ac, the skirt clearance h_g, and
  F_x and F_res.
- **(b)** the existing cushion pressure, peripheral leakage and rut-depth
  schematic.

Two new symbols, `L_wb` and `L_c`, were added to the Nomenclature. Nothing else
in the notation changed, and no existing symbol was reused.

One point handled deliberately: the sketch invited a centre-of-gravity offset,
which I left out. The model assumes equal load on all four wheels
(Section 2) and does not treat longitudinal load transfer. Drawing an offset CG
would advertise a capability the paper does not have and would invite a referee
question the manuscript cannot answer. The caption states that the equal wheel
reactions follow from that assumption.

Source: `code/fig2a_geometry.py`. Add it to the GitHub repository alongside the
other two scripts.

---

# Pass 5 — Fig. 2(a) final, and what to update on GitHub and Zenodo

## The three corrections to Fig. 2(a) are applied

1. The stray blue mark near `h_g` is gone. It was not a leftover object: the
   double-headed dimension arrow was being squeezed into a 12 mm gap, so its two
   arrowheads overlapped and rendered as an "x". The clearance is now shown with
   a leader line and a dot at the gap, which reads correctly at any size.
2. `G = mg` is now simply `G`, matching the Nomenclature.
3. A grey `v →` arrow marks the direction of travel, so the directions of
   `F_x` and `F_res` are self-evident.

The wheel reactions `W_w` point upward, as in the original drawing. That part of
the professor's free-body logic was never changed.

## How to put this to the professor

The honest framing is not "we replaced your figure". It is:

> The force system is unchanged. Only the geometric labels were renamed, because
> `b` and `L_p` are already defined in the manuscript as the tire contact patch
> width and the skirt perimeter, and reusing them for longitudinal dimensions
> would contradict Eqs. (4), (7), (8) and (11).

That is accurate and defensible, and it is the reason the second version is
actually the *safer* one for his figure: it preserves the physics and removes
the only thing a referee could call an error.

## GitHub — what to add to what you already have

You have `LICENSE`, `README.md`, `fig1_schematic.py`, `results.json`,
`terramechanics_model.py`. Add from `code/`:

- **`fig2a_geometry.py`** — new, draws Fig. 2(a).
- **`requirements.txt`** — numpy and matplotlib with minimum versions.
- **`CITATION.cff`** — citation metadata. GitHub renders a "Cite this
  repository" button from it and Zenodo reads it on archiving. Fill in the
  `repository-code` URL before committing.
- **Replace `README.md` and `terramechanics_model.py`** with the versions in
  `code/`. The model file gained the cross-comparison functions
  (`crosscheck_sinkage`, `crosscheck_traction`, `robustness_wheel_model`) and the
  rigid-wheel sinkage switch since the first deposit, and `results.json` was
  regenerated with them.
- **Replace `results.json`** with the current one.

Then run everything once from a clean clone and confirm the console log prints
nine passing limit checks and α\* = 0.642.

## Zenodo — yes, you need a new version, and there is a trap

Publishing a **new version** of the record gives that version its own DOI. The
DOI now printed in the manuscript, `10.5281/zenodo.21862564`, points at version
1 and will keep pointing at version 1 after you upload version 2. A reader
following it would get code that no longer matches the paper.

Two ways out, and I recommend the first.

**Option A — cite the concept DOI.** Every Zenodo record has an all-versions
("concept") DOI in addition to the per-version one. It is shown on the record
page as "Cite all versions" and always resolves to the newest version. Use that
in the paper. You will need to change one line in `refs.bib` and one in the Data
Availability statement, then rebuild. This is the standard practice for software
cited in a paper, and it survives every future update.

**Option B — publish version 2 first, then paste its version DOI** into the
manuscript before you submit. Simpler, but you must not touch the repository
again after that without repeating the exercise.

Either way, upload the new version *before* you submit, so the archived code
matches the manuscript exactly. Tag the GitHub release (`v1.1.0` matches
`CITATION.cff`) and let the GitHub–Zenodo integration create the version rather
than uploading files by hand.

---

# Revision 1 — response to JTERRA-D-26-00107 reviews

Reviewer 1 sent comments to the Editor only. Reviewer 2 raised seven points; all
seven are applied. One of them changed the central result of the paper.

## The one that mattered: Reviewer 2, comment 3

The reviewer noticed that propulsive power was computed as F_res·v/η_dr while
traction was evaluated at a fixed slip of 0.25, and asked whether slip was
prescribed rather than solved. It was, and the two were inconsistent: that
expression is the power delivered to the vehicle and omits the power dissipated
in shearing the soil.

**Slip is now solved.** In steady straight-line motion the drawbar pull is zero,
so the wheels develop exactly F_res and the slip is the root of
F_x(α, s_eq) = F_res. Eq. (9) is monotonic in s, so the root is unique; it is
found by bisection to 10⁻⁶. The power balance becomes
P_tot = F_res·v/[(1−s_eq)·η_dr] + Δp·Q/η_f, and the slip loss
F_res·v·s_eq/(1−s_eq) is now carried explicitly.

**What changed:**

| | before | after |
|---|---|---|
| α\* (organic) | 0.597 | **0.642** |
| P_tot\* | 28.8 kW | **29.6 kW** |
| operating window | 0.53–0.67 | **0.58–0.71** |
| α\* at 2.5 m/s | 0.44 | **0.49** |
| α\* at 10 m/s | 0.79 | **0.81** |
| Monte-Carlo ±15 % | [0.55, 0.64] | **[0.59, 0.69]** |
| Monte-Carlo ±30 % | [0.49, 0.68] | **[0.53, 0.73]** |
| snow saving | 8 % | **10 %** |
| rigid-wheel α\* | 0.74 | **0.82** |

**And a new result fell out of it.** The equilibrium slip rises steeply towards
the feasibility bound — 0.057 at α\*, 0.172 at α = 0.44, 0.26 at α = 0.40, where
the slip loss reaches 6.8 kW, over a fifth of the propulsive demand. It is the
slip loss, not the fan, that holds the optimum away from the bound. The old
slip-free balance could not express that mechanism at all. Figure 8 gained a
second panel showing the solved slip, and the slip loss is now plotted separately.

A second consequence: at α = 0 on organic soil the slip equation has **no
solution** — the wheels cannot develop the required thrust at any slip. There is
no steady state and no defined power demand. The 50.1 kW formerly quoted as the
baseline is now explicitly a notional figure with s_eq = 0, footnoted in Table 4
and quoted only to give a scale. That is a more honest statement than the earlier
comparison.

## The other six

2. **Assumed cushion parameters.** New four-paragraph note in Section 2 giving
   the basis, published range and quantified influence of h_g, C_d^leak, μ_sk and
   η_f. States that h_g is the single most influential assumption (P_fan ∝ h_g,
   Δα\* = 0.057 for ±20 %, increases with skirt wear, measurable on a static rig)
   and that μ_sk is the weakest-supported but least influential by two orders of
   magnitude.
4. **Rut depth > wheel radius.** New paragraph in Section 7.1: 0.568 m exceeds
   the 0.525 m radius, Eq. (4) is a plate-penetration law not supported by data
   at z > D/2, and hull drag and bulldozing are unmodelled. Also establishes that
   nothing depends on the magnitude — every feasible state satisfies z ≤ 0.35 m,
   i.e. z < D/2. New Limitation 8.
5. **Speed realism.** New paragraph in Section 7.4: sustained muskeg travel is
   slow and limited by roughness rather than power; 2.5 and 5 m/s correspond to
   that duty and 5 m/s is the reference for that reason; 7.5 and 10 m/s show the
   trend and approach the limit of the quasi-static treatment. The trend does not
   depend on them — α\* already moves 0.49 → 0.64 between 2.5 and 5 m/s.
1. **Hovercraft citations.** El-Khatib (2013) and Karami (2021) removed from text
   and bibliography: controller papers with no bearing on this design. Yun and
   Bliault and Amyot retained and now tied explicitly to Eqs. (10)–(11), which
   use them.
7. **Figure 2.** Rut depth z added to panel (a) with the depth dimensioned clear
   of the wheel; h_g was already there. Both already in panel (b).
6. **"anair" in the title.** The .tex reads correctly ("of an air-cushion-assisted");
   the error is in the Editorial Manager metadata, where a line break was lost.
   **You must fix this in the submission system — I cannot.**

## Files

`response_to_reviewers.docx` is the point-by-point reply, written to be uploaded
as the response document. It gives the location of every change and reports the
numerical shift openly rather than burying it.

Clean-room check passed: code copied to an empty directory reproduces all eight
limit checks (one new: F_x(α, s_eq) = F_res), α\* = 0.642, and all 22 figure files.

## Before you resubmit

- Fix the title in Editorial Manager.
- Push the updated `code/` to GitHub and publish a new Zenodo version; the model
  file changed substantially (equilibrium-slip solver, slip loss, notional
  baseline). Cite the concept DOI if you have not already, so the link tracks the
  newest version.
- Re-export Fig. 1 from CAD at 300 dpi if that is still outstanding.

---

# Revision 1, pass 2 — Reviewer 1's annotations, and the duplicated author block

## The author duplication: found and fixed, two separate causes

**In `manuscript.docx` it was a converter bug.** The frontmatter carried a
commented-out ORCID example:

```
%%   \author[lpnu]{Andrii Bokhonko\fnref{orc1}}
```

`make_docx.py` did not strip LaTeX comments before parsing, so it read four
authors instead of three and emitted Bokhonko twice. The converter now strips
comment text (respecting escaped `\%`) before parsing the frontmatter, and the
comment itself has been reworded so it contains no `\author` command. Verified:
one occurrence in the front matter.

**In `manuscript.pdf` it was the Highlights page.** With the `highlights`
environment inside the manuscript, elsarticle prints a Highlights page that
repeats the title and the full author line, and then the title page repeats them
again. The Guide for Authors asks for Highlights as a separate editable file
anyway, so the environment has been removed from the manuscript and
`Highlights.docx` is uploaded separately. The title and author block now appear
once.

## The title

`title_for_editorial_manager.txt` holds the title as a single line, ready to
paste. The `\title{}` in the source is now also on one line, so the line breaks
that produced "anair", "deformableterrain" and "energy-optimalload-relief"
cannot be lost again on copy-paste.

## Reviewer 1's annotated PDF — what it actually says

Reviewer 1 wrote nothing to the authors, but the PDF carries 16 highlights and
no comment text. Their positions are informative. Setting aside the ones on
section headings, which look like reading marks, they cluster on four things:

| Page | Highlighted | Reading |
|---|---|---|
| 6 | "aerocompensator"; "air-cushion load-relief system" | terminology |
| 9, 10 | h_g, and four rows of Table 1 (h_g *assumed*, A_ac, m, n_w/b/l *design study*) | the basis of the assumed parameters |
| 33 | the sentence on prioritising contact-patch characterisation over soil parameters | strength of the claim |
| 35 | "That configuration is itself traction-infeasible," | the baseline comparison |

**Three of those four are the same concerns Reviewer 2 raised**, and all four
were already addressed in this revision: the parameter-basis note (Section 2),
the qualified γ and priority claims (Sections 7.5 and 8), and the rewritten
baseline passage (Section 7.3). The terminology point has now been handled too —
"aerocompensator" appears once, in the Introduction.

This matters for the reply: Reviewer 1's reply box should acknowledge the
annotations and point to those sections rather than simply saying "no comments
to address". Draft text is in `EM_reply_boxes.md`.

## Other changes this pass

- Abstract retrimmed to 199 words after the slip sentence was added.
- Nomenclature: `F_def,F_roll,F_skirt,F_aero` and `P_fan,P_prop,P_tot` were
  overrunning their column and overlapping the description text. Split into one
  symbol per line; `P_slip` and `s_eq` added.
- Highlight 2 replaced to reflect the solved-slip change.

## Files to upload

| Item | File |
|---|---|
| Response to reviewers | `response_to_reviewers.docx` |
| Editorial Manager reply boxes | `EM_reply_boxes.md` — paste text, do not upload |
| Manuscript | `manuscript.pdf` (or `.docx`) |
| Highlights | `Highlights.docx` |
| Supplementary | `supplementary.pdf`, `code/` |
| Figures | `figures/` |
| Title metadata | `title_for_editorial_manager.txt` |
