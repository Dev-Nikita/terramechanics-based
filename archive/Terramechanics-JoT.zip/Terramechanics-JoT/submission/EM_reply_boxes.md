# Replies to paste into Editorial Manager

Editorial Manager requires a reply in the box under **every** comment before the
response can be sent. Below is the text for each box. The full point-by-point
document (`response_to_reviewers.docx`) is uploaded separately as the response
file; these boxes are short pointers into it.

---

## Reviewer 1 — reply box

> We thank Reviewer 1 for the time spent on the manuscript and for the annotated
> PDF. We note that the detailed comments were directed to the Editor, and we
> would be glad to respond to any of them that the Editor wishes to pass on.
>
> The annotated PDF marks several passages, and we have treated those marks as
> guidance. Three of them concern points that Reviewer 2 also raised, and all
> three have been addressed substantively in this revision: the basis of the
> assumed cushion parameters in Table 1, in particular the skirt clearance
> (new four-paragraph note, Section 2); the strength of the claim drawn from the
> contact-patch study (Section 7.5 and Section 8, both reworded); and the
> comparison against a traction-infeasible baseline (Section 7.3, rewritten
> after the power balance was corrected). The use of the term
> "aerocompensator" has also been reconsidered; it now appears once, in the
> Introduction, where the term used throughout the paper is introduced.
>
> Should the Editor forward further comments, we will address them in full.

---

## Reviewer 2 — reply box

> We thank Reviewer 2 for a careful and constructive review. Comment 3
> identified a genuine defect in the power balance rather than a point of
> presentation, and correcting it changed the central numerical result of the
> paper; we are grateful for it. All seven comments have been addressed, and the
> point-by-point response is uploaded as a separate file. In summary:
>
> 1. The two hovercraft-control references have been removed from the text and
>    the reference list. The two remaining air-cushion references are retained
>    because they are the source of the peripheral-jet lift and leakage
>    relations of Eqs. (10)–(11), and the sentence has been rewritten to say so.
>
> 2. A new note in Section 2 gives the basis, the published range and the
>    quantified influence of each assumed parameter. The skirt clearance is
>    identified as the single most influential assumption in the model, and the
>    skirt drag coefficient as the weakest-supported but least influential.
>
> 3. Slip was prescribed, and the power balance was inconsistent with it. Slip is
>    now solved from F_x(alpha, s_eq) = F_res (Eq. 14), and the slip loss is
>    carried explicitly. A new Section 3.7 sets this out and separates physical
>    existence of a steady state from operational admissibility: Eq. (15) states
>    the exact equivalence K_TR >= 1 <=> s_eq <= 0.25, and the two thresholds on
>    organic soil (a root from alpha = 0.35, admissibility only from
>    alpha_trac = 0.404) are reported as distinct. The verification suite now has
>    nine limit cases, and all results have been regenerated.
>    The optimum moved from alpha* = 0.597 to 0.642 and the mechanism behind it
>    is now reported: it is the slip loss, not the fan power, that holds the
>    optimum away from the feasibility bound.
>
> 4. A new paragraph in Section 7.1 states that the unassisted rut depth exceeds
>    the wheel radius, that the Bekker relation is not supported by data in that
>    range, and that hull drag and bulldozing are unmodelled. It also establishes
>    that no reported feasible state lies outside the valid range. A matching
>    limitation has been added.
>
> 5. A new paragraph in Section 7.4 explains the choice of speeds against
>    operating practice on organic terrain, identifies 2.5 and 5 m/s as the
>    realistic duty and 5 m/s as the reference point, and marks the higher speeds
>    as trend indicators that approach the limit of the quasi-static treatment.
>
> 6. Corrected. The error was in the title as entered in this system, where a
>    line break was lost; the manuscript file was correct. The metadata has been
>    retyped.
>
> 7. The rut depth has been added to Figure 2(a) alongside the skirt clearance,
>    which was already shown. Both are defined in the Nomenclature.
