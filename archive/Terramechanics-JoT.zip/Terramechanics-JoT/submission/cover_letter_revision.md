Nikita Tarasov
Institute of Mechanical Engineering and Transport
Lviv Polytechnic National University
S. Bandery St. 12, Lviv 79013, Ukraine

19 October 2026

Editor-in-Chief
Journal of Terramechanics

Dear Editor,

Please find enclosed the revised version of manuscript JTERRA-D-26-00107,
"Terramechanics-based evaluation of an air-cushion-assisted wheeled vehicle on
deformable terrain: feasibility limits and the energy-optimal load-relief
fraction".

We thank the Editor and both Reviewers for their careful reading. One comment
identified a genuine defect rather than a matter of presentation, and correcting
it changed the central numerical result of the paper.

Longitudinal slip was prescribed at the reference value while the power balance
omitted the power dissipated in shearing the soil. In the revised manuscript the
slip is solved from the traction–resistance equilibrium, and the slip loss is
carried in the energy balance. The revision also separates two conditions that
the original text ran together: the physical existence of a steady state, and
its operational admissibility at a slip an operator would sustain. The latter is
shown to be exactly equivalent to the feasibility indicator used throughout. All
numerical results, figures, tables, sensitivity and Monte-Carlo studies, the
abstract, the highlights and the conclusions have been regenerated from the
corrected model; the energy-optimal load-relief fraction on organic soil moves
from 0.597 to 0.642.

In addition, the basis and published range of each assumed air-cushion parameter
are now stated with their quantified influence; the limits of the
pressure–sinkage formulation at large rut depth are addressed explicitly; the
choice of operating speeds is justified against practice on organic terrain; two
references outside the scope of the study have been removed; and Figure 2 now
identifies the skirt clearance and the rut depth separately.

A point-by-point response to every comment accompanies this revision. The source
code used to produce the results reported in the manuscript is archived and
cited in the Data availability statement; it regenerates the figures, tables and
numerical values from the parameter sets given in Tables 1 and 2.

We hope the revised manuscript is now suitable for further consideration.

Yours sincerely,

Nikita Tarasov
Corresponding author, on behalf of all authors
