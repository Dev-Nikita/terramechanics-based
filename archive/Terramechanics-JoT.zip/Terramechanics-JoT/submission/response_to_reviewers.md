# Response to reviewers

**Manuscript:** JTERRA-D-26-00107
**Title:** Terramechanics-based evaluation of an air-cushion-assisted wheeled vehicle on deformable terrain: feasibility limits and the energy-optimal load-relief fraction
**Authors:** Andrii Bokhonko, Roman Zinko, Nikita Tarasov

We thank both reviewers for their time. Reviewer 2's third comment identified a
genuine defect in the power balance, and correcting it changed the central
numerical result of the paper; we are grateful for it. All comments are answered
below, with the location of each change in the revised manuscript, given by
section and page number of the revised version.

---

## Reviewer 1

The reviewer's detailed comments were directed to the Editor, and we would be
glad to respond to any of them the Editor wishes to pass on.

The annotated PDF supplied with the review marks a number of passages, and we
have treated those marks as guidance. Setting aside the section headings, which
appear to be reading marks, the marked passages fall into four groups, and each
has been addressed in this revision:

**The terminology of the title and introduction** ("aerocompensator";
"air-cushion load-relief system", p. 6). We have reconsidered the use of the
first term. It is established in the Ukrainian engineering literature but has
little currency in English-language terramechanics, so it now appears exactly
once, in the Introduction, where it is given as the local name for the device
before the term used throughout the paper is introduced. The title, abstract and
keywords do not use it.

**The skirt clearance and the basis of the Table 1 parameters** (p. 9; four
marks on Table 1, p. 10). This coincides with Reviewer 2's second comment, and
a new four-paragraph note has been added to Section 2 giving the basis, the
published range and the quantified influence of each assumed parameter. The note
identifies the skirt clearance as the single most influential assumption in the
model, explains why (fan power scales with the clearance, P_fan ∝ h_g), notes that skirt wear increases it
monotonically in service, and states that it is measurable on a static rig
without a running vehicle, which is why it heads the planned experimental
programme.

**The strength of the conclusion drawn from the contact-patch study** (p. 33).
The marked sentence has been reworded. It now reads that the results indicate
that characterizing the contact-patch response is more important than further
refinement of the soil parameters *used in the present model*, rather than
asserting a general ordering of research priorities. The related claim in
Section 7.5 was similarly qualified: the critical value of γ is stated to
be configuration- and terrain-dependent and to require experimental
determination, and the four scenarios examined are stated not to establish a
general threshold.

**The comparison against a traction-infeasible baseline** (p. 35). This passage
has been rewritten, and the correction of the power balance prompted by Reviewer
2's third comment changed what can honestly be said about it. At α = 0 on
organic soil the equilibrium-slip equation has no solution at all, so there is
no steady state and no defined power demand; the 50.1 kW
previously quoted is now explicitly identified as a notional figure obtained by
setting s_eq = 0, is footnoted as such in Table 4, and is quoted only to give a
scale. The text now states that the substantive effect of the cushion on this
terrain is the recovery of a steady state, not an energy saving between two
achievable regimes.

---

## Reviewer 2

### Comment 1
> The citation of the hovercraft over surfaces is not clear to me. Please remove the reference unless related to the algorithm/design that was studied.

**Agreed, and removed.** The two citations in question (El-Khatib and Hussein,
2013; Karami and Ghasemi, 2021) concerned stabilization and sliding-mode control
of fully supported hovercraft. Neither bears on the design or the analysis
presented here, which contains no controller and no fully supported regime. Both
have been deleted from the text and from the reference list.

The two remaining air-cushion references are retained because they are used, not
cited for context: Yun and Bliault (2000) and Amyot (1989) are the source of the
peripheral-jet lift and skirt-leakage relations of Eqs. (10) and (11) and of the
discharge-coefficient range discussed in Section 2. The sentence has been
rewritten to say so explicitly (Section 1.1, p. 5).

### Comment 2
> I wonder how the skirt clearance, discharge coefficient and skirt drag coefficient were obtained/assumed. It appears they have significant influence and it would help if the authors could provide a note on these parameters in a qualitative and quantitative manner.

**A new four-paragraph note has been added** (Section 2, pp. 7–8) giving the
basis of each assumed parameter, its published range where one exists, and its
quantified influence on the optimum. In summary:

| Parameter | Value | Basis | Published range | Influence on α\* |
|---|---|---|---|---|
| h_g | 10 mm | design target, lower end of flexible-skirt practice | 5–25 mm (Yun and Bliault, 2000) | 0.057 for ±20 % |
| C_d^leak | 0.60 | sharp-edged orifice; skirt hem treated as a plain gap | ≈0.5–0.7 | 0.042 for ±15 % |
| μ_sk | 0.05 | hem drag as a fraction of cushion lift, taken of the same order as tire rolling resistance | none located | 0.003 for ±20 % |
| η_f | 0.60 | ducted axial fan near its design point | — | 0.042 for ±15 % |

The note states plainly that h_g is the single most influential assumption in the
model, that P_fan ∝ h_g, that skirt wear increases it monotonically in service,
and that it is measurable on a static rig without a running vehicle — which is
why it heads the planned experimental programme in the Conclusions. It also
states that μ_sk is the weakest-supported of the four and simultaneously the
least influential, by two orders of magnitude relative to h_g.

### Comment 3
> In equation 14, I see that the propulsive power is computed with slip fixed at 0.25 but the power lost to slip doesn't seem to be included. Could the authors comment on this, as in, was the slip prescribed rather than solved? Please include a note on this segment in the manuscript.

**The reviewer is correct, and this was a defect rather than a simplification.**
Slip was prescribed at 0.25 for the traction evaluation while the power balance
used F_res·v/η_dr, which is the power delivered to the vehicle and omits the
power dissipated in shearing the soil. The two were inconsistent.

The model has been corrected. Slip is now **solved**, not prescribed. In steady
straight-line motion the drawbar pull is zero, so the wheels must develop exactly
the motion resistance, and the slip follows as the root of

> F_x(α, s_eq) = F_res(α)      (new Eq. 14)

Eq. (9) is monotonic in s, so the root is unique where one exists; it is found by
bisection to 10⁻⁶. All other quantities remain closed-form.

A new subsection, *Equilibrium slip and the energy boundary* (Section 3.7,
pp. 15–16), sets this out. Because the correction touches the feasibility
statement as well as the power balance, that subsection now separates two
conditions that the earlier text ran together:

* **Existence within the modelled slip range** — Eq. (14) has a root at all,
  i.e. the terrain can transmit more shear force at large slip than the motion
  resistance. The search is bounded at s = 0.9, which the revised text identifies
  as a limit of the model rather than an absolute physical limit on motion. On
  organic soil a root first appears at α = 0.35.
* **Operational admissibility** — that root lies at a slip an operator would
  sustain. The upper limit is the reference slip s = 0.25 of Table 1, stated in
  the revised text as an assumption of this study rather than a universal
  threshold. Because
  Eq. (9) is monotonic in s, this limit is *exactly* the indicator K_TR, which we
  now state as a numbered result:

> K_TR(α) ≥ 1 ⟺ F_x(α, 0.25) ≥ F_res(α) ⟺ s_eq(α) ≤ 0.25      (new Eq. 15)

The two conditions do **not** coincide, and the revised text says so explicitly:
on organic soil a root exists from α = 0.35, but only from α_trac = 0.404 does it
fall inside the slip limit. Between those values the vehicle could in principle
proceed, at slips of 0.25–0.77, which the model does not treat as an operating
state. Only the admissible region enters the optimization, and every reported
result lies inside it. This also clarifies what K_TR means in the paper: not an
abstract ratio, but the statement that the operating point can be held at an
admissible slip. The reference slip is used for that limit and for comparing
terrains at a common operating point, and **never** in the power balance, which
uses s_eq.

The wheel rim then advances at v/(1−s_eq) while the vehicle advances at v, and
the power balance becomes

> P_tot = F_res·v / [(1−s_eq)·η_dr] + Δp·Q/η_f,   P_slip = F_res·v·s_eq/(1−s_eq)   (Eq. 16)

Two further limit cases have been added to the verification suite, which now
contains **nine** cases (Table S1): the equivalence of Eq. (15) checked over 1901
values of α with zero mismatches, and F_x(α, s_eq) = F_res reproduced to within
1 N.

**This changed the central result, and in an instructive direction.** On organic
soil:

| | before | after |
|---|---|---|
| α\* | 0.597 | **0.642** |
| P_tot\* | 28.8 kW | **29.6 kW** |
| operating window | 0.53–0.67 | **0.58–0.71** |
| α\* at v = 2.5 m/s | 0.44 (constraint-bound) | **0.49** |
| Monte-Carlo ±30 % | [0.49, 0.68] | **[0.53, 0.73]** |

The reason is now reported in Section 7.3 and is a result in its own right: the
equilibrium slip rises steeply as the admissible bound is approached, from 0.057
at α\* to the limiting 0.25 at α_trac = 0.404, where the slip loss is 6.3 kW, or
**21 % of the propulsive demand, against 5 % at the optimum**. **It is the slip
loss, not the fan, that holds the optimum away from the feasibility bound** — a
mechanism the earlier slip-free balance could not express at all. A slip-free
balance places the optimum at 0.60 and understates the demand there by about
3 %, and understates it much more strongly near the bound. Figure 8 now has a
second panel showing the solved equilibrium slip, and the slip loss is plotted
separately in panel (a).

A further consequence is reported in Section 7.3: at α = 0 on organic soil Eq.
(14) has **no solution**, because the wheels cannot develop the required thrust at
any slip. There is therefore no steady state and no defined power demand. The
50.1 kW previously quoted as the unassisted baseline is now identified in
Table 4 and in the text as a notional figure obtained by setting s_eq = 0, quoted
only to give a scale; the rows concerned are footnoted accordingly. We think this
is a more honest statement of what the model says than the earlier comparison.

All tables, figures, Monte-Carlo intervals, sensitivity rankings, speed and
contact-patch studies, the abstract, the highlights and the conclusions have been
regenerated from the corrected model. The supplementary source code reproduces
every value.

### Comment 4
> The rut depth more than half a meter, which is greater than the wheel radius. I am not sure if this regime is valid for the pressure sinkage relationship. Please add a note and clarification in this regard.

**Agreed; the value is outside the validity of the relation and is now flagged as
such.** A new paragraph in Section 7.1 (p. 25) states that 0.568 m exceeds the
wheel radius of 0.525 m, so the wheel would be buried past its axle and the hull
would be in contact with the surface; that Eq. (4) is a plate-penetration law
calibrated for sinkages small compared with the loaded dimension, with no
published data supporting extrapolation to z > D/2; and that the model
additionally omits hull drag, soil flow over the hull and bulldozing resistance,
all of which would arise in that state.

The paragraph also establishes that **nothing in the analysis depends on that
magnitude.** The geometric constraint is violated once z exceeds 0.35 m, which
occurs at α < 0.440, and every feasible state reported in the paper satisfies
z ≤ 0.35 m, that is z < D/2, where the relation is applied as intended. The value
is therefore to be read as an indication that the unassisted configuration is far
outside its operating envelope, not as a prediction of settling depth. The same
reading applies to the γ ≥ 0.3 rows of Table 6. A corresponding limitation has
been added (Limitation 8).

### Comment 5
> The speeds of 5 to 10 m/s is high for such terrains, could the authors add a note on how the numerical studies mimics a real world operating example? I understand that the authors have added a note for future experimental tests, but a note on the realistic choice of parameters would be a good bridge to that study and increase confidence.

**A note has been added** (Section 7.4, p. 29). It states that sustained travel on
saturated muskeg is slow, limited by surface roughness, hummocks and the need to
avoid repeated passes rather than by installed power; that of the cases in
Table 5 only 2.5 and 5 m/s correspond to that duty, which is why 5 m/s was adopted
as the reference operating point; and that the 7.5 and 10 m/s rows are included
to show the direction and magnitude of the trend and are more representative of a
firmer section of a mixed route than of continuous muskeg travel.

The note also records that the upper rows approach the limit of the quasi-static
treatment, since vertical dynamics and cushion heave response — neither of which
is modelled — become significant at those speeds on rough organic ground. This is
now cross-referenced from Limitation 7. Finally, it points out that the trend does
not depend on the upper rows: α\* already moves from 0.49 to 0.64 between 2.5 and
5 m/s.

### Comment 6
> A minor comment, please check the word "anair" in the title.

**Thank you.** The error is in the title as entered in Editorial Manager, where
a line break was lost; the manuscript file itself reads "of an air-cushion-assisted"
correctly. We have corrected the submission-system metadata.

### Comment 7
> I recommend adding the skirt clearance, rut depth in Figure 2.

**Done.** Panel 2(b) already carried both; they are now also shown in panel 2(a),
where the force balance is defined. The figure now shows ruts beneath both wheels
with the depth z dimensioned clear of the wheel, alongside the skirt clearance h_g
which was already present. Both symbols appear in the Nomenclature.

---

## Summary of changes

- Slip solved rather than prescribed; slip loss added to the energy balance; new Section 3.7 and Eqs. (14)–(16), including the exact equivalence K_TR ≥ 1 ⇔ s_eq ≤ 0.25; physical existence of a steady state separated from operational admissibility; two new verification cases (nine in total); all numerical results regenerated. α\* moved from 0.597 to 0.642.
- New Figure 8(b): solved equilibrium slip. Slip loss plotted separately in 8(a).
- New s_eq column in Table 4 and Table S3; notional-baseline rows footnoted.
- New note on the basis of the four assumed cushion parameters (Section 2).
- New note on the validity of the pressure–sinkage relation at large sinkage (Section 7.1) and matching limitation.
- New note on the realism of the speed range (Section 7.4) and matching limitation.
- New limitation on the scope of the solved slip (steady, straight-line, zero drawbar pull).
- Two hovercraft-control references removed; the air-cushion references retained are now tied to the equations that use them.
- Rut depth z added to Figure 2(a).
- Abstract, highlights and conclusions rewritten to match; one highlight replaced.
- Title metadata corrected in Editorial Manager.
- The in-manuscript Highlights page has been removed, since the Highlights are supplied as a separate editable file as the Guide for Authors requires; the title and author block therefore now appear once only.
