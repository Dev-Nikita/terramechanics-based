# Что осталось сделать до нажатия Submit

## Блокеры — без них подавать нельзя

1. **Zenodo.** Сейчас DOI 10.5281/zenodo.21862564 открывает версию 0.2
   от 9 августа 2026 (архив 19,3 кБ) — это код ДО исправления скольжения.
   Статья в Data availability утверждает обратное.
   → Загрузить `zenodo/zenodo_v1.2.0.zip` как New version, проверить, что
   concept DOI резолвится на неё. Инструкция: `git/PUSH_COMMANDS.md`, §5.

2. **Figure 1.** Исходник 644 x 399 px, 72 dpi — около 182 dpi при ширине
   колонки 90 мм и 86 dpi на 190 мм. Elsevier требует 300 dpi (полутон) и
   500 dpi (combination art).
   → Переэкспортировать из CAD. Лучше всего вектор (PDF или EPS) — тогда
   вопрос снимается. Если растр: при 90 мм нужно >= 1063 px (300 dpi) или
   1772 px (500 dpi); при 190 мм — >= 2244 px или 3740 px.
   Растягивание имеющегося файла не поможет: деталей в нём нет.
   После замены положить файл в `manuscript/figures/fig1a_cad.png`
   (или .pdf и поправить includegraphics) и пересобрать.

## Делается только вами, в Editorial Manager

3. **Заголовок.** В системе он записан со слипшимся «anair» — ошибка в
   метаданных, в файле статьи заголовок правильный.
   → Вставить текст из `title_for_editorial_manager.txt` одной строкой.

4. **Corresponding author** — Nikita Tarasov, проверить адрес в `\ead{}`
   и в cover letter.

## Что загружать в ревизию

| Пункт | Файл |
|---|---|
| Revised Manuscript | `manuscript/build/article.pdf` (или .docx) |
| Supplementary Material | `manuscript/build/supplementary.pdf` |
| Highlights | `Highlights.docx` |
| Cover Letter | `cover_letter_revision.docx` |
| Response to Reviewers | `response_to_reviewers.docx` |
| Figures | `manuscript/figures/Fig*.png` или .pdf |

Ответы по каждому замечанию дополнительно вставить в поля `Reply to comment`
онлайн-системы — текст готов в `EM_reply_boxes.md`.
