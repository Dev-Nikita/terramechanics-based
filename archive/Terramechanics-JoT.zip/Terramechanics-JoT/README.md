# JTERRA-D-26-00107 — проект статьи

Terramechanics-based evaluation of an air-cushion-assisted wheeled vehicle on
deformable terrain: feasibility limits and the energy-optimal load-relief fraction

Статус: ревизия после первого раунда рецензирования, готова к повторной подаче
после двух действий — см. `submission/TODO_BEFORE_SUBMIT.md`.

## Структура

```
Terramechanics-JoT/
├── manuscript/            исходник статьи — НЕ публикуется
│   ├── article.tex             главный файл (elsarticle)
│   ├── supplementary.tex       таблицы S1–S5
│   ├── refs.bib                библиография (32 источника, все проверены)
│   ├── elsarticle.cls          класс журнала
│   ├── elsarticle-harv.bst     стиль библиографии
│   ├── make_docx.py            сборка DOCX из .tex (pandoc + препроцессор)
│   ├── figures/                все рисунки: рабочие имена + имена журнала
│   └── build/                  article.pdf, article.docx, supplementary.*
│
├── submission/            всё, что загружается в Editorial Manager — НЕ публикуется
│   ├── cover_letter_revision.{md,docx}   письмо на ревизию (использовать это)
│   ├── cover_letter.{md,docx}            письмо первой подачи (архив)
│   ├── response_to_reviewers.{md,docx}   постраничный ответ рецензентам
│   ├── EM_reply_boxes.md                 текст для полей Reply to comment
│   ├── Highlights.docx, highlights.txt
│   ├── title_for_editorial_manager.txt   заголовок одной строкой
│   ├── README_submission.md              полный журнал правок
│   └── TODO_BEFORE_SUBMIT.md             что осталось сделать
│
├── code/                  ЕДИНСТВЕННАЯ папка, которая уходит в Git и Zenodo
│   ├── terramechanics_model.py           вся модель
│   ├── fig1_schematic.py, fig2a_geometry.py
│   ├── results.json, requirements.txt
│   ├── README.md, LICENSE, CITATION.cff
│   └── .gitignore
│
├── zenodo/
│   └── zenodo_v1.2.0.zip   архив для загрузки новой версии записи
│
├── reviews/               отзывы рецензентов и аудиты (локально)
└── git/
    └── PUSH_COMMANDS.md    команды публикации — только код
```

## Пересборка статьи

```
cd manuscript
pdflatex article && bibtex article && pdflatex article && pdflatex article
python3 make_docx.py article.tex build/article.docx
```

46 страниц, 0 ошибок, 0 неопределённых ссылок и цитат.

## Воспроизведение расчётов

```
cd code
python3 -m pip install -r requirements.txt
python3 terramechanics_model.py
```

Девять аналитических проверок должны пройти, `results.json` должен совпасть с
тем, что лежит рядом.

## Правило публикации

Статья, ответы рецензентам и cover letter **никогда** не попадают в Git.
Репозиторий инициализируется внутри `code/`, а не в корне проекта — так
рукопись физически не может попасть в коммит. Подробности и команды — в
`git/PUSH_COMMANDS.md`.
